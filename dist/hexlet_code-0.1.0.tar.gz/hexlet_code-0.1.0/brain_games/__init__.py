"""Initialize class variables."""
